"""Current version of package epigenomic_dataset."""
__version__ = "1.2.2"